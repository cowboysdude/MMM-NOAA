#### Overview:

_( a detailed overview of the problem this ticket will solve and the targeted audience )_

#### Acceptance Criteria:

_( issue will not be considered complete unless this list of criteria is met, e.g. intended usage, expected functionality, specific metrics met, etc. )_

#### Steps to Duplicate _( required for bug reports )_:

_( a step by step guide written for a person who might be looking at this for the first time )_

#### System Info _( required for bug reports )_:

_( e.g. "iPhone 6 iOS 8.3" or "OSX 10.10 and Google Chrome Version 44.0.2403.89 (64-bit)" )_

#### Relevant Documentation _( optional )_

_( e.g. Screenshots, Github Issues, etc )_
